
@mainpage
@brief Calculator with basic mathematical operations, factorial, power, root, trigonometric functions and other.
@authors Hajek Karel
@authors Ladislav Ondris
@authors Rosinska Monika
@authors Rozsival Michal
